
const port = 4001; // what port we are going to be listening to


const http = require('http') // http- library
const fs = require('fs') // fs-library, file handling.
const request = require('request'); // Request library
const express = require('express'); // Express Library. 
const app = express();
/*
const express = require('express');
const app = express();

app.get('/', (req, res) => {
    res.send('An alligator approaches!');
});

app.listen(3000, () => console.log('Gator app listening on port 3000!'));
*/

// sets up public-folder as a static folder that can be reached with https-requests. 
app.use(express.static('public'));


// an example of GET - request. 
const server = http.createServer(function(req,res){// takes a request and a respons as parameters. 
res.writeHead(200, {'Content-Type': 'text/html'})  //tells the browser that we are going to write html. we should parse as html. 200 = something is working. 
fs.readFile('public/index.html', function(error,data) {
    if(error){
        res.writeHead(404)// means not found.
        res.write('Error: File Not Found') // outputs optional error message.
    }else {
        res.write(data) //prints the html.
    }
    res.end()

})

//Try this. 
// https://www.youatube.com/watch?v=Sb8xyCa2p7A for GET- and POST-requests.
// res.write('Hello Node') (prints Hello Node to the dom).


})


// imports the json in the terminal. Express Library.
request('https://localhost:3000/public/api/random', { json: true }, (err, res, body) => {
  if (err) { return console.log(err); }
  console.log(body);
});


// Valfritt POST request till terminalen.  (request library).
request('https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY', { json: true }, (err, res, body) => {
  if (err) { return console.log(err); }
  console.log(body.url);
  console.log(body.explanation);
  console.log('hello');
});




// Server is listening on port 3000. This is the output.
server.listen(port, function(error){
    if (error){
        console.log('Something went wrong', error) 
        }else {
            console.log('Server is listening on port ' + port)
        }
    })


