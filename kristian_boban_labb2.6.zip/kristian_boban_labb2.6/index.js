const express = require('express'); // imports the 'express'framework in Node.js
const router = express.Router();// Routing refers to how an application’s endpoints (URIs) respond to client requests
const app = express();


//Turns the folder 'public' into a static server. 
app.use(express.static('public'));



 // generates a random number between 1 and 1023 in the browser on localhost:4000; ASSIGNMENT VG 1. DONE
 let tal;
app.get('/api/random', (req, res) => {
    tal = Math.floor((Math.random() * 1023) + 1); 
    res.send({ number: tal });
});


// ASSIGNMENT VG 2. DONE


app.get('/api/custom_random/:num', (req, res) => {
    console.log(req.params)
    tal = Math.floor((Math.random() * req.params.num) + 1); // generates a random number between 1 and ?
    res.send({ number: tal });
});


// ASSIGNMENT VG 3.  

let count = 0;

app.get('/api/show', (req, res) => {

    res.send({ count: count});
});


app.get('/api/add', (req, res) => {

count = count + 1;

    res.send({success: true});
});

app.get('/api/add/:num', (req, res) => {

    count = count + parseInt(req.params.num);
    
        res.send({success: true});
    });

// 1. skapa en endpoint GET '/api/show' som returnerar ett json i formatet {count: 0}
// 2. skapa en till endpoint GET '/api/add' som returnerar ett json {success: true}
// efter anrop till /api/add skall ett anrop till /api/show visa {count: 1}

// alt.b gör en endpoint POST '/api/countvowels' 


// KRISTIAN, need your help here, followed this vid: https://www.youtube.com/watch?v=Sb8xyCa2p7A

/* router.get('/api/custom/num:id', (req, res, next) => {  // i am using Router() from the express-library.
   
res.render('num', {output: req.params.id});  // 'output' variable gets the end-point id written by the user. 

tal = Math.floor((Math.random() * output) + 1); // Generate a number between 0 and number specified in output. 

res.send({ number: tal}); // outputs the JSON. 

module.exports = router;
}); */



// /:id =  Expects an id get paramater after '/'. GET route.


// Sources for POST: https://www.youtube.com/watch?v=Sb8xyCa2p7A
// läs https://codeforgeek.com/handle-get-post-request-express-4/



// ASSIGNMENT VG 3. 
// Count Letters 



// function to count letters in a word. 
function wordCounter(word) {
  let numLetters = word.split("").length;
  return numLetters;
}

app.get('/api/letters', (req, res) => {

    res.send({ numberOfLetters: wordCounter('hallojsan')}); // change param. 
});

//går att vidareutvecklare. 
app.post('/api/letterstest', (req, res) => {

    
    res.send({ numberOfLetters: wordCounter('hallojsan')}); // change param. 
});


// What localhost port we are using. 
app.listen(4000);

