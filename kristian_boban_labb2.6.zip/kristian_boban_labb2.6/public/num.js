


let chooseNumber = JSON.parse(writtenNumber);

function returnNumber(chooseNumber){

    const tal =   Math.floor((Math.random() * chooseNumber) + 1); // generates a random number between 1 and chooseNumber

return tal; 
}
